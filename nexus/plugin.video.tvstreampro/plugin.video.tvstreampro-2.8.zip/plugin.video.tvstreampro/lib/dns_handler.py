# -*- coding: utf-8 -*-
import os
import requests

# Configuração do DNS do Cloudflare
CLOUDFLARE_DNS = "1.1.1.1"

def resolve_dns(domain):
    """
    Resolve um domínio usando o DNS do Cloudflare.
    """
    url = f"https://{CLOUDFLARE_DNS}/dns-query"
    headers = {
        "Accept": "application/dns-json",
    }
    params = {
        "name": domain,
        "type": "A",
    }
    try:
        response = requests.get(url, headers=headers, params=params, timeout=5)
        if response.status_code == 200:
            data = response.json()
            if "Answer" in data:
                return data["Answer"][0]["data"]
        return None
    except requests.exceptions.RequestException as e:
        print(f"Erro ao resolver DNS: {e}")
        return None


def log_dns_problem(file_path, dns, username, password):
    """
    Log DNS problems to a file.
    """
    problem_url = f"{dns}/get.php?username={username}&password={password}\n"

    # Create the file if it doesn't exist
    if not os.path.exists(file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            pass

    # Check if the problem is already logged
    with open(file_path, "r", encoding="utf-8") as f:
        if problem_url in f.read():
            return  # Already logged, skip

    # Log the problem
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(problem_url)

    print(f"Logged DNS problem: {problem_url}")


def notify_problem():
    """
    Notify the user about a DNS problem.
    """
    # Replace this with your custom notification logic
    print("LISTA OFFLINE :(")