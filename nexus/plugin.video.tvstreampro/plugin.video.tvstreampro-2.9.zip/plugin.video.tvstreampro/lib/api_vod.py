# -*- coding: utf-8 -*-
import logging
import re
from urllib.parse import urlparse, quote_plus
from bs4 import BeautifulSoup

try:
    from lib.ClientScraper import cfscraper, USER_AGENT
except ImportError:
    import cloudscraper
    cfscraper = cloudscraper.create_scraper()
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36"

try:
    from lib.helper import *
except ImportError:
    pass

class VOD:
    def __init__(self):
        self.base = 'https://superflixapi.dev'

    def tvshows(self, imdb, season, episode):
        stream = ''
        try:
            if imdb and season and episode:
                url = f'{self.base}/serie/{imdb}/{season}/{episode}'
                parsed_url_r = urlparse(url)
                r_ = f'{parsed_url_r.scheme}://{parsed_url_r.netloc}/'
                
                logging.info(f"Consultando URL da série: {url}")  # Log da URL
                
                r = cfscraper.get(url)
                src = r.text
                
                # Log do conteúdo completo da resposta HTML para diagnóstico
                logging.info(f"Conteúdo completo da resposta: {src[:1000]}...")  # Log dos primeiros 1000 caracteres da resposta
                
                soup = BeautifulSoup(src, 'html.parser')
                
                # Tentar encontrar o 'div' com o episódio ativo, ajustado para procurar apenas a classe 'episodeOption'
                div = soup.find('div', class_='episodeOption')
                
                # Log se não encontrar o div
                if not div:
                    logging.error("Não foi possível encontrar o 'div' com o episódio ativo. Verifique a estrutura da página.")
                    logging.info(f"HTML completo da página: {src}")  # Log do HTML completo para diagnóstico
                    raise ValueError("Não foi possível encontrar o 'div' com o episódio ativo.")
                
                data_contentid = div['data-contentid']
                logging.info(f"Data contentid encontrado: {data_contentid}")  # Log do contentid
                
                # Obter o vídeo
                api = f'{self.base}/api'
                r = cfscraper.post(api, data={'action': 'getOptions', 'contentid': data_contentid})
                
                # Verificação do conteúdo da resposta da API
                if r.status_code != 200:
                    logging.error(f"Erro na requisição à API: {r.status_code}")
                src = r.json()
                logging.info(f"Resposta da API: {src}")  # Log da resposta da API
                
                # Verificar se a resposta tem a estrutura esperada
                if 'data' not in src or 'options' not in src['data']:
                    logging.error("Estrutura da resposta da API inesperada. Dados não encontrados.")
                    return stream
                
                id_ = src['data']['options'][0]['ID']
                logging.info(f"ID obtido: {id_}")  # Log do ID
                
                # Obter o player
                r = cfscraper.post(api, data={'action': 'getPlayer', 'video_id': id_})
                
                # Verificação da resposta ao obter o player
                if r.status_code != 200:
                    logging.error(f"Erro ao obter o player da série: {r.status_code}")
                src = r.json()
                logging.info(f"Resposta do player: {src}")  # Log da resposta do player
                
                # Verificar se a resposta do player tem o campo esperado
                if 'data' not in src or 'video_url' not in src['data']:
                    logging.error("Estrutura da resposta do player inesperada. Dados do vídeo não encontrados.")
                    return stream
                
                video_url = src['data']['video_url']
                video_hash = video_url.split('/')[-1]
                parsed_url = urlparse(video_url)
                origin = f'{parsed_url.scheme}://{parsed_url.netloc}'
                player = f'{origin}/player/index.php?data={video_hash}&do=getVideo'
                
                logging.info(f"URL do player da série: {player}")  # Log da URL do player
                
                r = cfscraper.get(video_url, headers={'Referer': f'{self.base}/'})
                if r.status_code != 200:
                    logging.error(f"Erro ao acessar o vídeo da série: {r.status_code}")
                cookies_dict = r.cookies.get_dict()
                
                r = cfscraper.post(player, headers={'Origin': origin, 'x-requested-with': 'XMLHttpRequest'},
                                   data={'hash': str(video_hash), 'r': r_}, cookies=cookies_dict)
                if r.status_code != 200:
                    logging.error(f"Erro ao acessar o vídeo no player da série: {r.status_code}")
                src = r.json()
                stream = src['videoSource'] + '|User-Agent=' + quote_plus(USER_AGENT)
                
        except Exception as e:
            logging.exception(f"Erro na função tvshows: {e}")
        
        logging.info(f"Stream gerado da série: {stream}")  # Log do stream gerado
        return stream

    def movie(self, imdb):
        stream = ''
        try:
            if imdb:
                url = f'{self.base}/filme/{imdb}'
                parsed_url_r = urlparse(url)
                r_ = f'{parsed_url_r.scheme}://{parsed_url_r.netloc}/'
                
                logging.info(f"Consultando URL do filme: {url}")  # Log da URL
                
                r = cfscraper.get(url)
                src = r.text
                soup = BeautifulSoup(src, 'html.parser')
                div = soup.find('div', {'class': 'players_select'})  # dublado
                
                # Log se não encontrar o div
                if not div:
                    logging.error("Não foi possível encontrar o 'div' com os players disponíveis.")
                    raise ValueError("Não foi possível encontrar o 'div' com os players disponíveis.")
                
                data_id = div.find('div', {'class': 'player_select_item'}).get('data-id', '')
                logging.info(f"Data ID encontrado: {data_id}")  # Log do data-id
                
                api = f'{self.base}/api'
                r = cfscraper.post(api, data={'action': 'getPlayer', 'video_id': data_id})
                
                # Verificação da resposta ao obter o player
                if r.status_code != 200:
                    logging.error(f"Erro ao obter o player do filme: {r.status_code}")
                src = r.json()
                logging.info(f"Resposta do player: {src}")  # Log da resposta do player
                
                video_url = src['data']['video_url']
                video_hash = video_url.split('/')[-1]
                parsed_url = urlparse(video_url)
                origin = f'{parsed_url.scheme}://{parsed_url.netloc}'
                player = f'{origin}/player/index.php?data={video_hash}&do=getVideo'
                
                logging.info(f"URL do player do filme: {player}")  # Log da URL do player
                
                r = cfscraper.get(video_url, headers={'Referer': f'{self.base}/'})
                if r.status_code != 200:
                    logging.error(f"Erro ao acessar o vídeo do filme: {r.status_code}")
                cookies_dict = r.cookies.get_dict()
                
                r = cfscraper.post(player, headers={'Origin': origin, 'x-requested-with': 'XMLHttpRequest'},
                                   data={'hash': str(video_hash), 'r': r_}, cookies=cookies_dict)
                if r.status_code != 200:
                    logging.error(f"Erro ao acessar o vídeo do filme no player: {r.status_code}")
                src = r.json()
                stream = src['videoSource'] + '|User-Agent=' + quote_plus(USER_AGENT)
                
        except Exception as e:
            logging.exception(f"Erro na função movie: {e}")
        
        logging.info(f"Stream gerado do filme: {stream}")  # Log do stream gerado
        return stream