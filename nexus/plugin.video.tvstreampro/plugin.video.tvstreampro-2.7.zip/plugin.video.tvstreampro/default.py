# -*- coding: utf-8 -*-
import os
from lib.helper import *
from lib import xtream, tunein, pluto, imdb, api_vod
from lib.dns_handler import resolve_dns  # Importe a função de resolução de DNS

# BASIC CONFING
TITULO1 = '[B][COLOR cyan]d_b ||[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[B][COLOR green][++][/B][/COLOR] [B][COLOR cyan]|| d_b[/B][/COLOR]'
API_CHANNELS = 'https://raw.githubusercontent.com/BLACKSHEEPcolabdev/add-on/refs/heads/master/channels.json'
TITULO2 = '[B][COLOR cyan]d_b || [B][COLOR orange]TELEGRAM:[/B][/COLOR] [B][COLOR black]@BLACKGHOST_B[/B][/COLOR] [B]|| d_b[/B][/COLOR]'
TITULO3 = '[B][COLOR orange]======================================[/B][/COLOR]'
TITULO4 = '[B][COLOR orange]======================================[/B][/COLOR]'
TITULO5 = '[B][COLOR orange]======================================[/B][/COLOR]'
TITULO6 = '[B][COLOR orange]======================================[/B][/COLOR]'
if not exists(profile):
    try:
        os.mkdir(profile)
    except:
        pass
IPTV_PROBLEM_LOG = translate(os.path.join(profile, 'iptv_problems_log.txt'))


@route('/')
def index():
    addMenuItem({'name': TITULO1, 'description': '[B][COLOR green]BEM-VINDO AO [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][++]! APROVEITE FILMES E CANAIS AO VIVO EM UM SÓ LUGAR.[/COLOR]'}, destiny='')
    addMenuItem({'name': TITULO3, 'description': '[B][COLOR red]AVISO PRA QUEM ESTA ENFRENTANDO ERRO AO ASSISTIR OS CANAIS DE TV AO VIVO, ACONSELHAMOS O USO DE UMA [B][COLOR cyan]VPN[/B][/COLOR] [B]OU DE UM[/B] [B][COLOR cyan]DNS[/B][/COLOR] [B]PARA FUNCIONAR CORRETAMENTE OS CANAIS DE TV![/B][B][COLOR magenta] TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR].[/COLOR] [B][COLOR gold] OBRIGADO POR USAR NOSSO ADD-ONS[/B][/COLOR] [B][COLOR red]sz[/B][/COLOR]'}, destiny='')
    addMenuItem({'name': '[B]LISTA DE CANAIS IPTV[/B]', 'description': '[B][COLOR green]ACESSE LISTA DE CANAIS IPTV PERSONALIZADA NO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR]'}, destiny='/playlistiptv')
    if six.PY3:
        addMenuItem({'name': '[B]CANAIS - PLUTO TV[/B]', 'description': '[B][COLOR green]EXPLORE OS CANAIS DISPONÍVEIS NA PLUTO TV DIRETAMENTE PELO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR]'}, destiny='/channels_pluto')
    addMenuItem({'name': '[B]IMDB FILMES[/B]', 'description': '[B][COLOR green]CONFIRA OS FILMES POPULARES IMDB ATRAVÉS DO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR]'}, destiny='/imdb_movies')
    addMenuItem({'name': TITULO4, 'description': '[B][COLOR red]AVISO PRA QUEM ESTA ENFRENTANDO ERRO AO ASSISTIR OS CANAIS DE TV AO VIVO, ACONSELHAMOS O USO DE UMA [B][COLOR cyan]VPN[/B][/COLOR] [B]OU DE UM[/B] [B][COLOR cyan]DNS[/B][/COLOR] [B]PARA FUNCIONAR CORRETAMENTE OS CANAIS DE TV![/B][B][COLOR magenta] TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR].[/COLOR] [B][COLOR gold] OBRIGADO POR USAR NOSSO ADD-ONS[/B][/COLOR] [B][COLOR red]sz[/B][/COLOR]'}, destiny='')
    addMenuItem({'name': TITULO2, 'description': '[B][COLOR red]PRECISA DE AJUDA?[/B][/COLOR] [B][COLOR green]ENTRE EM CONTATO PARA SUPORTE AO[/B][/COLOR] [B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR]'}, destiny='')
    end()
    setview('WideList')

@route('/playlistiptv')
def playlistiptv(): 
    iptv = xtream.parselist(API_CHANNELS)
    if iptv:
        for n, (dns, username, password) in enumerate(iptv):
            n = n + 1
            addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]LISTA d[ [B][COLOR pink]{0}[/B][/COLOR] [B]]b[/B][/COLOR]'.format(str(n)), 'description': '[B][COLOR red]AVISO PRA QUEM ESTA ENFRENTANDO ERRO AO ASSISTIR OS CANAIS DE TV AO VIVO, ACONSELHAMOS O USO DE UMA [B][COLOR cyan]VPN[/B][/COLOR] [B]OU DE UM[/B] [B][COLOR cyan]DNS[/B][/COLOR] [B]PARA FUNCIONAR CORRETAMENTE OS CANAIS DE TV![/B][B][COLOR magenta] TVSTREAMPRO[/B][/COLOR][B][COLOR green][++][/B][/COLOR].[/COLOR] [B][COLOR gold] OBRIGADO POR USAR NOSSO ADD-ONS[/B][/COLOR] [B][COLOR red]sz[/B][/COLOR].', 'dns': dns, 'username': str(username), 'password': str(password)}, destiny='/cat_channels')
        end()
        setview('WideList')
    else:
        notify('SEM LISTA M3U')
        xbmc.log("Erro ao carregar lista IPTV", xbmc.LOGERROR)  # Log de erro



@route('/cat_channels')
def cat_channels(param):
    dns = param.get('dns')
    username = param.get('username')
    password = param.get('password')

    if not dns or not username or not password:
        xbmc.log("Erro: Parâmetro ausente", xbmc.LOGERROR)
        notify('Erro: Faltando parâmetros necessários.')
        return

    # Resolve o DNS usando a função definida
    resolved_dns = resolve_dns(dns)
    if not resolved_dns:
        log_dns_problem(IPTV_PROBLEM_LOG, dns, username, password)
        notify('Erro ao resolver DNS. Verifique a conexão e tente novamente.')
        return

    # Substitua o DNS pelo endereço IP resolvido
    try:
        cat = xtream.API(resolved_dns, username, password).channels_category()
        if cat:
            for i in cat:
                name, url = i
                addMenuItem({'name': name, 'description': '', 'dns': resolved_dns, 'username': str(username), 'password': str(password), 'url': url}, destiny='/open_channels')
            end()
            setview('WideList')
        else:
            log_dns_problem(IPTV_PROBLEM_LOG, resolved_dns, username, password)
            notify('Erro ao carregar categorias de canais. Tente novamente mais tarde.')
    except Exception as e:
        xbmc.log(f"Erro ao tentar acessar categorias de canais: {str(e)}", xbmc.LOGERROR)
        notify('Erro ao tentar acessar categorias de canais. Verifique a configuração ou tente novamente.')

@route('/open_channels')
def open_channels(self, url):
    try:
        # Tenta obter os canais da URL
        channels = xtream.API().channels_open(url)
        
        # Se os canais forem retornados, verifica se há canais disponíveis
        if channels:
            setcontent('videos')  # Define o tipo de conteúdo como 'vídeos'
            for channel in channels:
                name = channel.get('name', '').strip()
                link = channel.get('link', '').strip()
                thumb = channel.get('thumb', '')
                desc = channel.get('desc', '')
                
                # Verifica se o nome e o link são válidos antes de adicionar ao menu
                if name and link:
                    addMenuItem(
                        {'name': name, 'description': desc, 'iconimage': thumb, 'url': link},
                        destiny='/play_iptv', folder=False
                    )
                else:
                    xbmc.log(f"Canal {name} ou link inválido para: {url}", xbmc.LOGWARNING)
            
            # Exibe a lista de canais para o usuário
            endDirectory()
        else:
            # Se nenhum canal for encontrado, notifica o erro
            xbmc.log(f"Nenhum canal encontrado para a URL: {url}", xbmc.LOGERROR)
            notify('Nenhum canal encontrado')
    except Exception as e:
        # Caso ocorra algum erro, registra o erro no log
        xbmc.log(f"Erro ao abrir os canais para a URL {url}: {str(e)}", xbmc.LOGERROR)
        notify(f'Erro ao abrir canais: {str(e)}')


@route('/play_iptv')
def play_iptv(param):
    name = param['name']
    description = param['description']
    iconimage = param['iconimage']
    url = param['url']

    # Resolve o DNS antes de continuar
    resolved_url = resolve_dns(url)
    
    # Configura o item de reprodução com o protocolo correto
    list_item = xbmcgui.ListItem(path=resolved_url)
    list_item.setContentLookup(False)
    list_item.setArt({"thumb": iconimage})
    list_item.setMimeType("application/vnd.apple.mpegurl")
    list_item.setProperty("inputstream", "inputstream.ffmpegdirect")
    list_item.setProperty("inputstream.ffmpegdirect.stream_mode", "1")  # 1 para HLS
    
    # Define informações do vídeo
    list_item.setInfo("video", {"Title": name, "Plot": description})
    
    # Inicia a reprodução
    try:
        xbmc.Player().play(item=resolved_url, listitem=list_item)
    except Exception as e:
        xbmc.log(f"Erro ao tentar reproduzir: {e}", xbmc.LOGERROR)

@route('/channels_pluto')
def channels_pluto():
    channels = pluto.playlist_pluto()
    if channels:
        setcontent('movies')
        for channel in channels:
            channel_name,desc,thumbnail,stream = channel
            addMenuItem({'name': channel_name, 'description': desc, 'iconimage': thumbnail, 'url': stream}, destiny='/play_iptv2', folder=False)
        end()
        setview('List') 



@route('/play_iptv2')
def play_iptv2(param):
    url = param.get('url', '')

    # Resolve o DNS antes de prosseguir
    resolved_url = resolve_dns(url)

    # Extrai os cabeçalhos, se existirem
    header = unquote_plus(resolved_url.split('|')[1]) if '|' in resolved_url else ''

    # Configura o item de reprodução com o protocolo correto
    play_item = xbmcgui.ListItem(path=resolved_url)
    play_item.setContentLookup(False)
    play_item.setArt({"icon": "DefaultVideo.png", "thumb": param.get('iconimage', '')})
    play_item.setMimeType("application/vnd.apple.mpegurl")  # Use MIME correto para o fluxo

    # Ajuste para usar FFmpegDirect (sem inputstreamhelper)
    play_item.setProperty('inputstreamaddon', 'ffmpegdirect')  # Especifica o uso de ffmpegdirect

    # Se necessário, configure cabeçalhos de request para o fluxo
    if '|' in resolved_url:
        play_item.setProperty("inputstream.adaptive.manifest_headers", header)

    # Defina propriedades adicionais conforme necessário
    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
    play_item.setProperty('inputstream.adaptive.is_realtime_stream', 'true')

    # Define informações do vídeo
    if kversion > 19:
        info = play_item.getVideoInfoTag()
        info.setTitle(param.get('name', 'PLUTO TV'))
        info.setPlot(param.get('description', ''))
    else:
        play_item.setInfo(type="Video", infoLabels={"Title": param.get('name', ''), "Plot": param.get('description', '')})    

    # Inicia a reprodução com o FFmpegDirect
    try:
        xbmc.Player().play(item=resolved_url, listitem=play_item)
    except Exception as e:
        xbmc.log(f"Erro ao tentar reproduzir: {e}", xbmc.LOGERROR)


@route('/radios')
def radios():
    tunein.radios_list(API_RADIOS)

@route('/imdb_movies')
def imdb_series():
    addMenuItem({'name': '[B][COLOR magenta]TVSTREAMPRO[++][/B][/COLOR] - [B][COLOR gold]FILMES POPULARES[/B][/COLOR]', 'description': 'FILMES POPULARES COM BASE NA API DO SUPERFLIX'}, destiny='/imdb_movies_popular')
    end()
    setview('WideList')


@route('/find_movies')
def find_movies():
    search = input_text(heading='Pesquisar')
    if search:
        itens = imdb.IMDBScraper().search_movies(search)
        if itens:
            setcontent('movies')
            for i in itens:
                name,img,page,year,imdb_id = i
                addMenuItem({'name': name, 'description': '', 'iconimage': img, 'url': '', 'imdbnumber': imdb_id}, destiny='/play_resolve_movies', folder=False)
            end()
            setview('Wall') 

@route('/find_series')
def find_series():
    search = input_text(heading='Pesquisar')
    if search:
        itens = imdb.IMDBScraper().search_series(search)
        if itens:
            setcontent('tvshows')
            for i in itens:
                name,img,page,year,imdb_id = i
                addMenuItem({'name': name, 'description': '', 'iconimage': img, 'url': page, 'imdbnumber': imdb_id}, destiny='/open_imdb_seasons')
            end()
            setview('Wall')                 


@route('/imdb_movies_250')
def movies_250():
    itens = imdb.IMDBScraper().movies_250()
    if itens:
        setcontent('movies')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': '', 'imdbnumber': imdb_id}, destiny='/play_resolve_movies', folder=False)
        end()
        setview('Wall') 



@route('/imdb_series_250')
def series_250():
    itens = imdb.IMDBScraper().series_250()
    if itens:
        setcontent('tvshows')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': url, 'imdbnumber': imdb_id}, destiny='/open_imdb_seasons')
        end()
        setview('Wall')

@route('/imdb_movies_popular')
def movies_popular():
    itens = imdb.IMDBScraper().movies_popular()
    if itens:
        setcontent('movies')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': '', 'imdbnumber': imdb_id}, destiny='/play_resolve_movies', folder=False)
        end()
        setview('Wall')  

@route('/imdb_series_popular')
def series_popular():
    itens = imdb.IMDBScraper().series_popular()
    if itens:
        setcontent('tvshows')
        for i in itens:
            name,image,url,description, imdb_id = i
            addMenuItem({'name': name, 'description': description, 'iconimage': image, 'url': url, 'imdbnumber': imdb_id}, destiny='/open_imdb_seasons')
        end()
        setview('Wall') 

@route('/open_imdb_seasons')
def open_imdb_seasons(param):
    serie_icon = param.get('iconimage', '')
    serie_name = param.get('name', '')
    url = param.get('url', '')
    imdb_id = param.get('imdbnumber', '')
    itens = imdb.IMDBScraper().imdb_seasons(url)
    if itens:
        setcontent('tvshows')
        try:
            addMenuItem({'name': '::: ' + serie_name + ':::', 'description': '', 'iconimage': serie_icon}, destiny='')
        except:
            pass
        for i in itens:
            season_number, name, url_season = i
            addMenuItem({'name': name, 'description': '', 'iconimage': serie_icon, 'url': url_season, 'imdbnumber': imdb_id, 'season': season_number, 'serie_name': serie_name}, destiny='/open_imdb_episodes')
        end()
        setview('List')

@route('/open_imdb_episodes')
def open_imdb_episodes(param):
    serie_icon = param.get('iconimage', '')
    serie_name = param.get('serie_name', '')
    url = param.get('url', '')
    imdb_id = param.get('imdbnumber', '')
    season = param.get('season', '')
    itens = imdb.IMDBScraper().imdb_episodes(url)
    if itens:
        setcontent('tvshows')
        try:
            addMenuItem({'name': '::: ' + serie_name + ' - S' + str(season) + ':::', 'description': '', 'iconimage': serie_icon}, destiny='')
        except:
            pass 
        for i in itens:
            episode_number,name,img,fanart,description = i
            name_full = str(episode_number) + ' - ' + name
            #if not '#' in name_full and not '.' in name_full:
            addMenuItem({'name': name_full, 'description': description, 'iconimage': img, 'fanart': fanart, 'imdbnumber': imdb_id, 'season': season, 'episode': str(episode_number), 'serie_name': serie_name, 'playable': 'true'}, destiny='/play_resolve_series', folder=False)
        end()
        setview('List')

@route('/play_resolve_movies')
def play_resolve_movies(param):
    notify('Aguarde')
    # json_rpc_command = '''
    # {
    #     "jsonrpc": "2.0",
    #     "method": "Settings.SetSetting",
    #     "params": {
    #         "setting": "locale.languageaudio",
    #         "value": "por"
    #     },
    #     "id": 1
    # }
    # '''
    # xbmc.executeJSONRPC(json_rpc_command)
    import inputstreamhelper
    #serie_name = param.get('serie_name')
    #season = param.get('season', '')
    #episode = param.get('episode', '')
    iconimage = param.get('iconimage', '')
    imdb = param.get('imdbnumber', '')
    description = param.get('description', '')
    #name = serie_name + ' S' + str(season) + 'E' + str(episode)
    name = param.get('name', '')
    url = api_vod.VOD().movie(imdb)
    if url:
        notify('Escolha o audio portugues nos ajustes')

        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            if '|' in url:
                header = unquote_plus(url.split('|')[1])
            play_item = xbmcgui.ListItem(path=url)
            play_item.setContentLookup(False)
            play_item.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
            play_item.setMimeType("application/vnd.apple.mpegurl")
            if kversion >= 19:
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
            else:
                play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
            if '|' in url:
                play_item.setProperty("inputstream.adaptive.manifest_headers", header)
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            play_item.setProperty('inputstream.adaptive.is_realtime_stream', 'true')
            play_item.setProperty('inputstream.adaptive.original_audio_language', 'pt') 
            if kversion > 19:
                info = play_item.getVideoInfoTag()
                info.setTitle(name)
                info.setPlot(description)
                info.setIMDBNumber(str(imdb))
                #info.setSeason(int(season))
                #info.setEpisode(int(episode))
            else:
                play_item.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
                play_item.setInfo('video', {'imdbnumber': str(imdb)})
                #play_item.setInfo('video', {'season': int(season)})
                #play_item.setInfo('video', {'episode': int(episode)})

            #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)
            xbmc.Player().play(item=url, listitem=play_item)
    else:
        notify('STREAM INDISPONIVEL') 

@route('/play_resolve_series')
def play_resolve_series(param):
    # json_rpc_command = '''
    # {
    #     "jsonrpc": "2.0",
    #     "method": "Settings.SetSetting",
    #     "params": {
    #         "setting": "locale.languageaudio",
    #         "value": "por"
    #     },
    #     "id": 1
    # }
    # '''
    # xbmc.executeJSONRPC(json_rpc_command)
    import inputstreamhelper
    serie_name = param.get('serie_name')
    season = param.get('season', '')
    episode = param.get('episode', '')
    iconimage = param.get('iconimage', '')
    imdb = param.get('imdbnumber', '')
    description = param.get('description', '')
    name = serie_name + ' S' + str(season) + 'E' + str(episode)
    url = api_vod.VOD().tvshows(imdb,season,episode)
    if url:
        notify('ESCOLHA O AUDIO PT NOS AJUSTES')

        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            if '|' in url:
                header = unquote_plus(url.split('|')[1])
            play_item = xbmcgui.ListItem(path=url)
            play_item.setContentLookup(False)
            play_item.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
            play_item.setMimeType("application/vnd.apple.mpegurl")
            if kversion >= 19:
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
            else:
                play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
            play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
            if '|' in url:
                play_item.setProperty("inputstream.adaptive.manifest_headers", header)
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            play_item.setProperty('inputstream.adaptive.is_realtime_stream', 'true')
            play_item.setProperty('inputstream.adaptive.original_audio_language', 'pt') 
            if kversion > 19:
                info = play_item.getVideoInfoTag()
                info.setTitle(name)
                info.setPlot(description)
                info.setIMDBNumber(str(imdb))
                info.setSeason(int(season))
                info.setEpisode(int(episode))
            else:
                play_item.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
                play_item.setInfo('video', {'imdbnumber': str(imdb)})
                play_item.setInfo('video', {'season': int(season)})
                play_item.setInfo('video', {'episode': int(episode)})

            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)
    else:
        notify('STREAM INDISPONIVEL')  



